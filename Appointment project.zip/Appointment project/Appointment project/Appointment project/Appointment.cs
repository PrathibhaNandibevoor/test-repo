﻿using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Contexts;

public class Appointment
{
    public int Id { get; set; }
    public DateTime DateTime { get; set; }
}

