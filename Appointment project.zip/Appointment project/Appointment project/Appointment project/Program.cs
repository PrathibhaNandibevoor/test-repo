﻿
using System;


class Program
{
    static void Main(string[] args)
    {
        // Check if at least one command is provided
        if (args.Length == 0)
        {
            Console.WriteLine("No command provided.");
            return;
        }

        // Parse the first command and call the appropriate method
        var command = args[0].ToUpper();
        var appointmentService = new AppointmentService(new AppointmentsDbContext());
        var parser = new CommandLineParser(appointmentService);

        switch (command)
        {
            case "ADD":
                parser.ParseAddCommand(args);
                break;
            case "DELETE":
                parser.ParseDeleteCommand(args);
                break;
            case "FIND":
                parser.ParseFindCommand(args);
                break;
            case "KEEP":
                parser.ParseKeepCommand(args);
                break;
            default:
                Console.WriteLine("Invalid command.");
                break;
        }

        // Wait for user input before exiting
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}