﻿using System;
using System.Linq;

public class AppointmentService
{
    private readonly AppointmentsDbContext _dbContext;

    public AppointmentService(AppointmentsDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public void AddAppointment(DateTime dateTime)
    {
        var appointment = new Appointment { DateTime = dateTime };
        _dbContext.Appointments.Add(appointment);
        _dbContext.SaveChanges();
        Console.WriteLine("Appointment added successfully.");
    }

    public void DeleteAppointment(DateTime dateTime)
    {
        var appointment = _dbContext.Appointments.FirstOrDefault(a => a.DateTime == dateTime);
        if (appointment != null)
        {
            _dbContext.Appointments.Remove(appointment);
            _dbContext.SaveChanges();
            Console.WriteLine("Appointment deleted successfully.");
        }
        else
        {
            Console.WriteLine("No appointment found for the given date and time.");
        }
    }

    public DateTime FindFreeTimeslot(DateTime date)
    {
        using (var context = new AppointmentsDbContext())
        {
            DateTime endDate = date.Date.AddDays(1); // Calculate the end of the date range

            var appointments = context.Appointments
                .Where(a => a.DateTime >= date.Date && a.DateTime < endDate)
                .ToList();
            var currentTime = date.Date.AddHours(9); // Start checking from 9 AM

            // Check if the current date falls within the third week of the month
            int weekOfMonth = (date.Day - 1) / 7 + 1;
            bool isSecondDayOfThirdWeek = (weekOfMonth == 3 && date.DayOfWeek == DayOfWeek.Tuesday);

            while (currentTime.Hour < 17) // Until 5 PM
            {
                // Check if the current time is between 4 PM and 5 PM on the second day of the third week
                if (isSecondDayOfThirdWeek && currentTime.Hour == 16)
                {
                    // Skip this time slot and move to the next 30-minute interval
                    currentTime = currentTime.AddMinutes(30);
                    continue;
                }

                if (!appointments.Any(a => a.DateTime == currentTime))
                {
                    return currentTime;
                }

                currentTime = currentTime.AddMinutes(30); // Increment by 30 minutes
            }

            return DateTime.MinValue; // No free timeslot found
        }
    }

    public void KeepTimeslot(DateTime dateTime)
    {
        // Check if the specified time falls within the acceptable range (9 AM to 4 PM)
        if (dateTime.Hour >= 9 && dateTime.Hour < 16)
        {
            // Check if the specified time is not on every second day of the third week of any month from 4 PM to 5 PM
            if (!(dateTime.Day % 2 == 0 && dateTime.DayOfWeek == DayOfWeek.Friday && dateTime.Hour == 16))
            {
                // Add appointment only if it meets the conditions
                var appointment = new Appointment { DateTime = dateTime };
                _dbContext.Appointments.Add(appointment);
                _dbContext.SaveChanges();
                Console.WriteLine("Timeslot kept successfully.");
            }
            else
            {
                Console.WriteLine("The specified timeslot cannot be kept due to scheduling constraints.");
            }
        }
        else
        {
            Console.WriteLine("Timeslot must be between 9 AM and 4 PM.");
        }
    }
}