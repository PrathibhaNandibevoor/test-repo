﻿using System;

public class CommandLineParser
{
    private readonly AppointmentService _appointmentService;

    public CommandLineParser(AppointmentService appointmentService)
    {
        _appointmentService = appointmentService;
    }

    public void Parse(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("No command provided.");
            return;
        }

        string command = args[0].ToUpper();
        switch (command)
        {
            case "ADD":
                ParseAddCommand(args);
                break;
            case "DELETE":
                ParseDeleteCommand(args);
                break;
            case "FIND":
                ParseFindCommand(args);
                break;
            case "KEEP":
                ParseKeepCommand(args);
                break;
            default:
                Console.WriteLine("Invalid command.");
                break;
        }
    }

    public void ParseAddCommand(string[] args)
    {
        // Check if the correct number of arguments is provided for the ADD command
        if (args.Length != 3)
        {
            Console.WriteLine("Usage: ADD DD/MM hh:mm");
            return;
        }

        // Extract the date and time arguments from the command-line input
        string date = args[1];
        string time = args[2];
        string dateTimeString = $"{date} {time}";

        // Parse the date and time string into a DateTime object
        if (DateTime.TryParseExact(dateTimeString, "dd/MM HH:mm", null, System.Globalization.DateTimeStyles.None, out DateTime dateTime))
        {
            // Call the AppointmentService method to add the appointment
            _appointmentService.AddAppointment(dateTime);
            Console.WriteLine("Appointment added successfully.");
        }
        else
        {
            Console.WriteLine("Invalid date/time format. Usage: ADD DD/MM hh:mm");
        }
    }

    public void ParseDeleteCommand(string[] args)
    {
        // Check if the correct number of arguments is provided for the DELETE command
        if (args.Length != 3)
        {
            Console.WriteLine("Usage: DELETE DD/MM hh:mm");
            return;
        }

        // Extract the date and time arguments from the command-line input
        string date = args[1];
        string time = args[2];
        string dateTimeString = $"{date} {time}";

        // Parse the date and time string into a DateTime object
        if (DateTime.TryParseExact(dateTimeString, "dd/MM HH:mm", null, System.Globalization.DateTimeStyles.None, out DateTime dateTime))
        {
            // Call the AppointmentService method to delete the appointment
            _appointmentService.DeleteAppointment(dateTime);
            Console.WriteLine("Appointment deleted successfully.");
        }
        else
        {
            Console.WriteLine("Invalid date/time format. Usage: DELETE DD/MM hh:mm");
        }
    }

    public void ParseFindCommand(string[] args)
    {
        // Check if the correct number of arguments is provided for the FIND command
        if (args.Length != 2)
        {
            Console.WriteLine("Usage: FIND DD/MM");
            return;
        }

        // Extract the date argument from the command-line input
        string date = args[1];

        // Parse the date string into a DateTime object
        if (DateTime.TryParseExact(date, "dd/MM", null, System.Globalization.DateTimeStyles.None, out DateTime parsedDate))
        {
            // Call the AppointmentService method to find a free timeslot
            DateTime freeTimeslot = _appointmentService.FindFreeTimeslot(parsedDate);
            if (freeTimeslot != DateTime.MinValue)
            {
                Console.WriteLine($"First free timeslot on {parsedDate.ToShortDateString()}: {freeTimeslot.ToString("HH:mm")}");
            }
            else
            {
                Console.WriteLine("No free timeslots available for the specified date.");
            }
        }
        else
        {
            Console.WriteLine("Invalid date format. Usage: FIND DD/MM");
        }
    }

    public void ParseKeepCommand(string[] args)
    {
        // Check if the correct number of arguments is provided for the KEEP command
        if (args.Length != 2)
        {
            Console.WriteLine("Invalid KEEP command. Usage: KEEP hh:mm");
            return;
        }

        // Extract the time argument from the command-line input
        string time = args[1];
        string dateTimeString = $"{DateTime.Today.ToString("dd/MM")} {time}";

        // Parse the time string into a DateTime object
        if (DateTime.TryParseExact(dateTimeString, "dd/MM HH:mm", null, System.Globalization.DateTimeStyles.None, out DateTime dateTime))
        {
            // Call the AppointmentService method to keep a timeslot
            _appointmentService.KeepTimeslot(dateTime);
            Console.WriteLine($"Timeslot {dateTime.ToString("HH:mm")} has been kept.");
        }
        else
        {
            Console.WriteLine("Invalid time format. Please use hh:mm");
        }
    }
}