﻿using System;
using System.Data.Entity;

public class AppointmentsDbContext : DbContext
{
    public DbSet<Appointment> Appointments { get; set; }

    public AppointmentsDbContext() : base(@"Server=.;Database=AppointmentsDB;Trusted_Connection=True;")
    { 
    }
}