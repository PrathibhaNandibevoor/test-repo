using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace YourNamespace.Tests
{
    [TestFixture]
    public class AppointmentServiceTests
    {
        private List<DateTime> _appointments;

        [SetUp]
        public void Setup()
        {
            // Initialize the list of appointments before each test
            _appointments = new List<DateTime>();
        }

        [Test]
        public void AddAppointment_ValidDateTime_AppointmentAddedSuccessfully()
        {
            // Arrange
            DateTime dateTime = new DateTime(2024, 3, 18, 10, 0, 0); // Hardcoded date and time

            // Act
            AddAppointment(dateTime);

            // Assert
            Assert.IsTrue(_appointments.Contains(dateTime));
        }

        [Test]
        public void DeleteAppointment_ExistingDateTime_AppointmentDeletedSuccessfully()
        {
            // Arrange
            DateTime dateTime = new DateTime(2024, 3, 18, 10, 0, 0); // Hardcoded date and time
            _appointments.Add(dateTime); // Add the appointment to be deleted

            // Act
            DeleteAppointment(dateTime);

            // Assert
            Assert.IsFalse(_appointments.Contains(dateTime));
        }

        private void AddAppointment(DateTime dateTime)
        {
            // Simulate adding the appointment to a repository or collection
            _appointments.Add(dateTime);
        }

        private void DeleteAppointment(DateTime dateTime)
        {
            // Simulate deleting the appointment from a repository or collection
            _appointments.Remove(dateTime);
        }
    }
}