INSERT INTO Appointments (DateTime) VALUES ('2024-03-15 14:30:00');

DELETE FROM Appointments WHERE DateTime = '2024-03-15 14:30:00';

SELECT TOP 3 DateTime 
FROM Appointments 
WHERE DateTime >= '2024-03-15' 
AND DateTime < '2024-03-16'
ORDER BY DateTime;

